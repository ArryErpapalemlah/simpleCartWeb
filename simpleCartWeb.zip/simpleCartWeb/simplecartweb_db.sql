-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2023 at 09:12 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simplecartweb_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `userId` varchar(10) NOT NULL,
  `productId` varchar(10) NOT NULL,
  `productName` varchar(100) NOT NULL,
  `productPrice` int(100) NOT NULL,
  `productImage` varchar(255) NOT NULL,
  `productQuantity` int(100) NOT NULL,
  `totalPrice` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(10) NOT NULL,
  `userId` varchar(10) NOT NULL,
  `productId` varchar(10) NOT NULL,
  `productName` varchar(100) NOT NULL,
  `productPrice` int(100) NOT NULL,
  `productImage` varchar(255) NOT NULL,
  `productQuantity` int(100) NOT NULL,
  `totalPrice` int(100) NOT NULL,
  `totalCoupoun` int(10) DEFAULT NULL,
  `startDate` datetime NOT NULL,
  `dateExpire` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `userId`, `productId`, `productName`, `productPrice`, `productImage`, `productQuantity`, `totalPrice`, `totalCoupoun`, `startDate`, `dateExpire`) VALUES
(1, 'USR001', 'WS001', 'Tech.Inc Solar Pocket Calculator', 120000, 'img/calculator.jpg', 1, 120000, 4, '2023-08-16 12:44:42', '2023-08-16 15:44:42'),
(2, 'USR001', 'WS002', 'WS Exercise Book 8mm 36 Leaves A4', 25000, 'img/book.jpg', 2, 50000, NULL, '2023-08-16 12:44:42', '2023-08-16 15:44:42'),
(3, 'USR001', 'WS003', 'Paper Mate Inkjoy 100RT Blue Mid 12 Pack', 65000, 'img/pen.jpg', 1, 65000, NULL, '2023-08-16 12:44:42', '2023-08-16 15:44:42'),
(4, 'USR001', 'WS003', 'Paper Mate Inkjoy 100RT Blue Mid 12 Pack', 65000, 'img/pen.jpg', 1, 65000, 1, '2023-08-16 01:49:15', '2023-08-16 16:49:15'),
(5, 'USR001', 'WS003', 'Paper Mate Inkjoy 100RT Blue Mid 12 Pack', 65000, 'img/pen.jpg', 1, 65000, 1, '2023-08-16 01:52:24', '2023-08-16 16:52:24');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `productId` varchar(10) NOT NULL,
  `productName` varchar(100) NOT NULL,
  `productImage` varchar(255) NOT NULL,
  `productPrice` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `productId`, `productName`, `productImage`, `productPrice`) VALUES
(1, 'WS001', 'Tech.Inc Solar Pocket Calculator', 'img/calculator.jpg', 120000),
(2, 'WS002', 'WS Exercise Book 8mm 36 Leaves A4', 'img/book.jpg', 25000),
(3, 'WS003', 'Paper Mate Inkjoy 100RT Blue Mid 12 Pack', 'img/pen.jpg', 65000),
(4, 'WS004', 'WS Highlighter Assorted 4 Pack', 'img/highlighter.jpg', 10000),
(5, 'WS005', 'WS End Cap HB Pencil 10 Pack', 'img/pencil.jpg', 55000),
(6, 'WS006', 'WS Large Eraser White 2 Pack', 'img/rubber.jpg', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `userId` varchar(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `userId`, `username`, `password`) VALUES
(1, 'USR001', 'user', 'ee11cbb19052e40b07aac0ca060c23ee');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
