<?php

class SimpleWebCartModel extends CI_Model
{
	public function getDataProduct()
    {
        $this->db->select('*');
        $this->db->from('products');
        $query = $this->db->get();
        return $query;
    }

    public function getSingleDataProduct($productId) 
    {
        $this->db->select('*');
        $this->db->from('products');
        $this->db->where('productId', $productId);
        $query = $this->db->get();
        return $query;
    }

    public function checkSingleDataCart($productId) 
    {
        $this->db->select('*');
        $this->db->from('cart');
        $this->db->where('productId', $productId);
        $query = $this->db->get();
        return $query;
    }

    public function insertCart($data) 
    {
        $this->db->insert('cart', $data);
        return $this->db->insert_id();
    }

    public function updateCartQuantity($productId, $productQuantity, $totalPrice) 
    {
        $this->db->where('productId',$productId);
        return $this->db->update('cart', ['productQuantity' => $productQuantity, 'totalPrice' => $totalPrice]);
    }

    public function getCartQuantityNumber()
    {
        $this->db->select_sum('productQuantity');
        $this->db->from('cart');
        $this->db->where('userId', $this->session->userdata("userId"));
        $query = $this->db->get();
        return $query;

    }

    public function getUserDataCart()
    {
        $this->db->select('*');
        $this->db->from('cart');
        $this->db->where('userId', $this->session->userdata("userId"));
        $query = $this->db->get();
        return $query;        
    }

    public function insertHistory($data) 
    {
        $this->db->insert('history', $data);
        return $this->db->insert_id();
    }

    public function delUserCart()
    {
        return $this->db->delete('cart', ['userId' => $this->session->userdata("userId")]); 
    }

    public function getUserDataHistory()
    {
        $this->db->select('*');
        $this->db->from('history');
        $this->db->where('userId', $this->session->userdata("userId"));
        $query = $this->db->get();
        return $query;        
    }
}
