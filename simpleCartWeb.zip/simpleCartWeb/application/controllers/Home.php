<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('SimpleWebCartModel');
    }


	public function index()
	{
		$data['title'] = "Product";
		$data['QuantityNumber'] = $this->SimpleWebCartModel->getCartQuantityNumber();
		$data['getDataProduct'] = $this->SimpleWebCartModel->getDataProduct();
		$this->load->view('header', $data);
		$this->load->view('homePage');
		$this->load->view('footer');
	}

	public function processCart($productId)
	{
		$getSingleDataProduct = $this->SimpleWebCartModel->getSingleDataProduct($productId)->result();
		$checkSingleDataCart  = $this->SimpleWebCartModel->checkSingleDataCart($productId)->result();
		$productId="";$productName="";$productPrice="";$productImage="";$productQuantity = "";$totalPrice="";
		
		foreach ($getSingleDataProduct as $row) {
			$productId= $row->productId;
			$productName= $row->productName;
			$productPrice= $row->productPrice;
			$productImage= $row->productImage;
		}

		if($checkSingleDataCart) {
			foreach ($checkSingleDataCart as $row) {
				$productQuantity= $row->productQuantity + 1;
				$totalPrice= $row->totalPrice + $productPrice;
			}			
			$this->SimpleWebCartModel->updateCartQuantity($productId, $productQuantity, $totalPrice);		
			redirect('Home');
		} else {
			$data = array(
				'productId' => $productId,
				'userId' => $this->session->userdata("userId"),
				'productName' => $productName,
				'productPrice' => $productPrice,
				'productImage' => $productImage,
				'productQuantity' => 1,
				'totalPrice' => $productPrice,
			);
			$this->SimpleWebCartModel->insertCart($data);
			redirect('Home');
		}
		
	}
}
