<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class History extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('SimpleWebCartModel');
    }

	public function index()
	{
		date_default_timezone_set('Asia/jakarta');
		$data['title'] = "History";
		$data['QuantityNumber'] = $this->SimpleWebCartModel->getCartQuantityNumber();
		$data['getUserDataHistory'] = $this->SimpleWebCartModel->getUserDataHistory();
		$getUserDataHistoryy = $this->SimpleWebCartModel->getUserDataHistory();
		$totalcoupon=0; $totalprices=0;
		foreach ($getUserDataHistoryy->result() as $row) {
			$totalcoupon = $totalcoupon + $row->totalCoupoun;
			$totalprices = $totalprices + $row->totalPrice;			
		}
		$data['totalcoupon'] = $totalcoupon;
		$data['totalprices'] = $totalprices;
		$this->load->view('header', $data);
		$this->load->view('historyPage');
		$this->load->view('footer');
	}	
}
