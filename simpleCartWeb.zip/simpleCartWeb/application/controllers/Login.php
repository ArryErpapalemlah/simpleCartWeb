<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->library('session');
		$this->load->model('SimpleWebCartModel');
    }

	public function index()
	{
		#to make sure that user doesn't go back to login page after login
        if ($this->session->userdata('username')) {
            redirect('Home');
        }
		$this->load->library('form_validation');

        $this->form_validation->set_rules('inputusername', 'Username', 'trim|required');
        $this->form_validation->set_rules('inputpassword', 'Password', 'trim|required');

        if ($this->form_validation->run() == false) {
            $data['title'] = "Login Simple Web Cart";
			$this->load->view('login/loginHeader', $data);
			$this->load->view('login/loginPage');
			$this->load->view('login/loginFooter');
        } else {
            $this->_login();
        }
	}

	private function _login()
    {
        $username = $this->input->post('inputusername', true);
        $password = md5($this->input->post('inputpassword', true));
        $check_usr = $this->db->get_where('users', ['username' => $username])->row_array();

		if($check_usr){
			if($password == $check_usr['password']){
				$sesdata = array(
					'id' => $check_usr['id'],
					'userId' => $check_usr['userId'],
					'username' => $check_usr['username'],
					'logged_in' => true
				);
				$this->session->set_userdata($sesdata);
				redirect('Home');
				} else {
					#password salah
					$this->session->set_flashdata(
						'msg',
						'
										<div class="alert alert-danger alert-dismissible" role="alert">
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;&nbsp; &nbsp;</span>
											</button>
											<strong>Gagal!</strong> username atau password anda salah!.
										</div>'
					);
					redirect('Login');
				}
		} else {
			#username salah
			$this->session->set_flashdata(
                'msg',
                '
											<div class="alert alert-danger alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
												 </button>
												 <strong>Gagal!</strong> username atau password anda salah!.
											</div>'
            );
            redirect('Login');
		}
    }

	public function logout()
    {
		$this->SimpleWebCartModel->delUserCart();
        $this->session->sess_destroy();
        redirect('');
    }
}
