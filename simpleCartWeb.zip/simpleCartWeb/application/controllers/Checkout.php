<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('SimpleWebCartModel');
    }


	public function index()
	{
		date_default_timezone_set('Asia/jakarta');
		$data['title'] = "Checkout";
		$data['QuantityNumber'] = $this->SimpleWebCartModel->getCartQuantityNumber();
		$data['getUserDataCart'] = $this->SimpleWebCartModel->getUserDataCart();
		$getUserDataCartss= $this->SimpleWebCartModel->getUserDataCart();
		$data['kupon']=0; $data['totalPrices'] = 0;
		foreach ($getUserDataCartss->result() as $row) {
			$row->productPrice;
			$data['totalPrices'] = $data['totalPrices'] + $row->totalPrice;
			if($row->productPrice >= 51000) {
				$data['kupon']++;
			}
		}
		$data['kupon'] = $data['kupon'] + (floor($data['totalPrices']/100000));
		$this->load->view('header', $data);
		$this->load->view('checkoutPage');
		$this->load->view('footer');

		if (isset($_POST['btnchecOut'])){
			$expireDate = date('Y-m-d H:i:s', strtotime('+ 3 hours'));
			$kuponFinal = $data['kupon'];
			foreach ($getUserDataCartss->result() as $row) {
				$data=array(
					'userId' => $row->userId,
					'productId' => $row->productId,
					'productName' => $row->productName,
					'productPrice' => $row->productPrice,
					'productImage' => $row->productImage,
					'productQuantity' => $row->productQuantity,
					'totalPrice' => $row->totalPrice,
					'totalCoupoun' => $kuponFinal,
					'startDate' => date('y-m-d h:i:s'),
					'dateExpire' =>	$expireDate			
				);
				$this->SimpleWebCartModel->insertHistory($data);
			}
			$this->SimpleWebCartModel->delUserCart();
			redirect("History");
		}
	}

	
}
