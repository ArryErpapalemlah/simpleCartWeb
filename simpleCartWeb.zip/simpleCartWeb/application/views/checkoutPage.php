<main class="page">
	 	<section class="shopping-cart dark">
	 		<div class="container">
		        <div class="block-heading">
		          <h2>Shopping Cart</h2>
		          <p>We hope you enjoy your shopping experience.</p>
		        </div>
		        <div class="content">
              <form method="POST">
                <div class="row">
                  <?php foreach($getUserDataCart->result() as $row){?>
                  <div class="items">
                      <div class="product">
                        <div class="row">
                          <div class="col-md-3">
                            <img class="img-fluid mx-auto d-block image" src="<?php echo base_url('assets/'); ?><?= $row->productImage ?>">
                          </div>
                          <div class="col-md-8">
                            <div class="info">
                              <div class="row">
                                <div class="col-md-5 product-name">
                                  <div class="product-name">
                                    <h6><b><?= $row->productName; ?></b></h6>
                                  </div>
                                </div>
                                <div class="col-md-4 quantity">
                                  <label for="quantity">Quantity:</label>
                                  <br>
                                  <span><?= $row->productQuantity; ?></span>
                                </div>
                                <div class="col-md-3 price">
                                  <span><?= $row->productPrice; ?></span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php } ?>
                </div> 
                <div class="summary">
                  <h3>Summary</h3>
                  <div class="summary-item"><span class="text">Total Coupon</span><span class="price"><?= $kupon ?></span></div>
                  <div class="summary-item"><span class="text">Total Price</span><span class="price"><?= $totalPrices ?></span></div>
                  <button type="submit" class="btn btn-primary btn-lg btn-block" name="btnchecOut">Checkout</button>
                </div>
              </form>
            </div>
	 		</div>
		</section>
	</main>