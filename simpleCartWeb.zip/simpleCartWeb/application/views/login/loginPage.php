<div class="text-center">
	<form method="post" action="<?= base_url(''); ?>" class="form-signin">
		<img class="mb-4" src="<?php echo base_url('assets/'); ?>img/logo.png" alt="" width="85" height="82">
		<h1 class="h3 mb-3 font-weight-normal">Welcome to Simple Web Cart</h1>
		<?= $this->session->flashdata('msg'); ?>
		<label for="inputUsername" class="sr-only">Email address</label>
		<input type="text" id="inputUsername" name="inputusername" class="form-controll" placeholder="Username" required autofocus>
		<label for="inputPassword" class="sr-only">Password</label>
		<input type="password" id="inputPassword" name="inputpassword" class="form-controll" placeholder="Password" required>
		<div class="checkbox mb-3">
		</div>
		<button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
		<p class="mt-5 mb-3 text-muted">&copy; 2023</p>
	</form>
</div>

	
