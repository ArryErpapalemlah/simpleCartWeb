<div class="container">
  <div class="block-heading" style="padding-top: 50px;margin-bottom: 40px;text-align: center; font-family: 'Montserrat', sans-serif;">
    <h2 style="margin-bottom: 1.2rem;color: #3b99e0;">Shopping History</h2>
		<p style="text-align: center;max-width: 420px;margin: auto;opacity: 0.7;">We hope you enjoy your shopping experience.</p>
	</div>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">No</th>
        <th scope="col">Product Image</th>
        <th scope="col">Product Name</th>
        <th scope="col">Product Price</th>
        <th scope="col">Product Quantity</th>
        <th scope="col">Total Price</th>
        <th scope="col">Status</th>
      </tr>
    </thead>
    <?php $no=1; foreach($getUserDataHistory->result() as $row) { ?>
    <tbody>
      <tr>
        <th scope="row"><?= $no ?></th>
        <td><img style="width: 30%;height: 30%;"src="<?php echo base_url('assets/'); ?><?= $row->productImage ?>"></td>
        <td><?= $row->productName ?></td>
        <td>Rp. <?= number_format($row->productPrice) ?></td>
        <td><?= $row->productQuantity ?></td>
        <td>Rp. <?= number_format($row->totalPrice) ?></td>
        <td><?php
        if(date('Y-m-d h:i:s') >= $row->dateExpire)
        {
          echo("Close");
        }else {
          echo("Open");
        }
        
        ?></td>
      </tr>
    </tbody>
    <?php $no++; } ?>
  </table>
  <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col"></th>
      <th scope="col"></th>
      <th scope="col"><b>Total Coupon: </b><?= $totalcoupon ?></th>
      <th scope="col"><b>Total Price: Rp. </b><?= number_format($totalprices) ?></th>
    </tr>
  </thead>
</table>
</div>

