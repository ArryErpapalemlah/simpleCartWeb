<section class="shopping-cart dark">
    <div class="container">
        <div class="block-heading" style="padding-top: 50px;margin-bottom: 40px;text-align: center; font-family: 'Montserrat', sans-serif;">
        <h2 style="margin-bottom: 1.2rem;color: #3b99e0;">Product</h2>
            <p style="text-align: center;max-width: 420px;margin: auto;opacity: 0.7;">We you can get the best stationaries for your needs.</p>
        </div>
        <div class="row">
            <?php
            if($getDataProduct->num_rows() > 0 ) {
                foreach ($getDataProduct->result() as $row) {
                    
            ?>
            <div class="col-sm-6 col-md-4 col-lg-4 mb-2" id="test">
                <div class="card-deck">
                    <div class="card p-2 border-secondary mb-2">
                        <img class="mb-4" src="<?php echo base_url('assets/'); ?><?= $row->productImage ?>" alt="">
                        <div class="card-body p-1">
                            <h4 class="card-title text-center">
                                <?= $row->productName ?>
                            </h4>
                            <h5 class="card-text text-center">
                                Rp. <?= number_format($row->productPrice); ?>
                            </h5>
                            <div class="card-footer p-1">
                                <a href="<?= base_url('Home/processCart/' . $row->productId) ?>" class="btn btn-info btn-block"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to cart</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php 
                }
            }?>
        </div>

    </div> <!-- /container -->
</section>