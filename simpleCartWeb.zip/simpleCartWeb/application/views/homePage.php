<section class="shopping-cart dark">
    <div class="container">

        <h1>Bootstrap grid examples</h1>
        <p class="lead">Basic grid layouts to get you familiar with building within the Bootstrap grid system.</p>

        <h3>Five grid tiers</h3>
        <p>There are five tiers to the Bootstrap grid system, one for each range of devices we support. Each tier starts at a minimum viewport size and automatically applies to the larger devices unless overridden.</p>

        <div class="row">
            <?php
            if($getDataProduct->num_rows() > 0 ) {
                foreach ($getDataProduct->result() as $row) {
                    
            ?>
            <div class="col-sm-6 col-md-4 col-lg-4 mb-2" id="test">
                <div class="card-deck">
                    <div class="card p-2 border-secondary mb-2">
                        <img class="mb-4" src="<?php echo base_url('assets/'); ?><?= $row->productImage ?>" alt="">
                        <div class="card-body p-1">
                            <h4 class="card-title text-center">
                                <?= $row->productName ?>
                            </h4>
                            <h5 class="card-text text-center">
                                Rp. <?= number_format($row->productPrice); ?>
                            </h5>
                            <div class="card-footer p-1">
                                <a href="<?= base_url('Home/processCart/' . $row->productId) ?>" class="btn btn-info btn-block"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to cart</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php 
                }
            }?>
        </div>

    </div> <!-- /container -->
</section>